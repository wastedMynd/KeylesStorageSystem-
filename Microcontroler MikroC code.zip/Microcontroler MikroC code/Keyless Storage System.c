//Weight senor Module
//Parcel Module
//PARCEL CONNECTION
char parcel0;
char parcel1;
char parcel2;
//END OF PARCEL CONNECTION
//end of Parcel Module
//ADC
//ADC0831 Module conmection
sbit cs at P1_0_bit;
sbit clk at P1_1_bit;
sbit dO at P1_2_bit;
sbit dI at P1_3_bit;
//end of ADC0831 Module conection
unsigned char *ascii = "000";
unsigned char reading;
void initADC()
{
 cs =1;
 dO =0;
 dI =0;
 clk = 0;

 delay_us(2);

 clk = 1;
 cs = 0;
 dO = 1;
}

void clkADC()
{
     clk = 0;
     delay_us(2);
     clk = 1;
     delay_us(2);
     clk = 0;
}

unsigned char getADCReading(char parcel)
{

  char x;
  initADC();
  clkADC();
  dI= parcel;
  
  for(x=0;x<8;x++)
  {
     reading = reading<<1;
     clk= 1;
     if(dO==1)reading++;
     clk= 0;
  }

  return reading;
}

unsigned char *convertToAscii(unsigned char val)
{

  ascii[0] = val /100 + 48;
  ascii[1] = (val/10)%10 + 48;
  ascii[2] = val % 10 + 48;
  return ascii;
}
//end of ADC0831 Module

//end Weight senor Module

//Lock Module
sbit lock0 at P2_0_bit;
sbit lock1 at P2_1_bit;
sbit lock2 at P2_2_bit;

sbit door0 at P2_3_bit;
sbit door1 at P2_4_bit;
sbit door2 at P2_5_bit;

void setLock(char lock, char status)
{
  if(lock== 0 &&  door0 == 0)lock0 = status;
  else if(lock == 1 && door1 == 0)lock1 = status;
  else if(lock == 2 && door2 == 0)lock2 = status;
}

char storageHasWeight(char parcel)
{
  return (getADCReading(parcel) > 26)? 1:0;
}

char getDoorStatusAt(char door)
{
    char status = 0;
    if(door == 0)status = door0;
    else if(door == 1)status = door1;
    else if(door == 2)status = door2;
    return status;
}
//end Lock Module

//Raspbery Pi Interface
char current_cmd,previous_cmd;
char *lock,*status;


void RaspberryPiComs() iv IVT_ADDR_ES ilevel 0 ics ICS_AUTO {
 char cmd;
 if(ri_bit==1)//Raspberry Pi is transmitting
 {
     P1_6_bit =1;
     P1_7_bit =0;
     
     current_cmd = sbuf;
     
     switch(sbuf)
     {
      ///locks
      case 'a':
      case 'b':
      case 'c':
      ///weight
      case 'd':
      case 'e':
      case 'f':
      previous_cmd = current_cmd;
      break;
     }

     //locking and unlocking; lock0  Raspberry Pi sends 'a',followed by 'l' unlocks and 'L' to lock
     //                       lock1  Raspberry Pi sends 'b',followed by 'l' unlocks and 'L' to lock
     //                       lock1  Raspberry Pi sends 'c',followed by 'l' unlocks and 'L' to lock
     switch(previous_cmd)
     {
       case 'a':
       if(current_cmd== 'l')setLock(0,0);
       else if(current_cmd=='L')setLock(0,1);
       break;
       
       case 'b':
       if(current_cmd== 'l')setLock(1,0);
       else if(current_cmd=='L')setLock(1,1);
       break;
       
       case 'c':
       if(current_cmd== 'l')setLock(2,0);
       else if(current_cmd=='L')setLock(2,1);
       break;
     }
     
     //monitor wieght sensor; parcel0  Raspberry Pi sends 'd', micro controller transmits back a 'p' meaning these no parcel and 'P' these a parcel
     //                       parcel1  Raspberry Pi sends 'e', micro controller transmits back a 'p' meaning these no parcel and 'P' these a parcel
     //                       parcel2  Raspberry Pi sends 'f', micro controller transmits back a 'p' meaning these no parcel and 'P' these a parcel
     switch(previous_cmd)
     {
       case 'd':
       ri_bit =0;
       sbuf = (storageHasWeight(0)== 0) ? 'p': 'P';
       break;
       
       case 'e':
       ri_bit =0;
       sbuf = (storageHasWeight(1)== 0) ? 'p': 'P';
       break;
       
       case 'f':
       ri_bit =0;
       sbuf = (storageHasWeight(2)== 0) ? 'p': 'P';
       break;
     }
     
     //monitor door; door0  Raspberry Pi sends 'g', micro controller transmits back a 'd' meaning the door is open and 'D' door is closed
     //              door1  Raspberry Pi sends 'h', micro controller transmits back a 'd' meaning the door is open and 'D' door is closed
     //              door2  Raspberry Pi sends 'i', micro controller transmits back a 'd' meaning the door is open and 'D' door is closed
     switch(current_cmd)
     {
         case 'g':
         ri_bit=0;
         sbuf = (getDoorStatusAt(0) == 0) ? 'D': 'd';
         break;
         
         case 'h':
         ri_bit=0;
         sbuf = (getDoorStatusAt(1) == 0) ? 'D': 'd';
         break;
     
         case 'i':
         ri_bit=0;
         sbuf = (getDoorStatusAt(2) == 0) ? 'D': 'd';
         break;
     }
     ri_bit =0;        //acknowledge Rpi3 transmittion
 }
 
 if(ti==1)   //uC transmiting
 {
  P1_6_bit =0;
  P1_7_bit =1;
  ti_bit =0; //acknowledge Rpi3 reception
 }
}

//end of Raspberry Pi Interface


// Lcd module connections
sbit LCD_RS at P0_0_bit;
sbit LCD_EN at P0_1_bit;

sbit LCD_D4 at P0_2_bit;
sbit LCD_D5 at P0_3_bit;
sbit LCD_D6 at P0_4_bit;
sbit LCD_D7 at P0_5_bit;
// End Lcd module connections

void main() {

  char parcelAt;
  char *weight;

  Lcd_Init();                        // Initialize Lcd
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  LCD_Out(1,3,"welcome");

  ea_bit =1;
  es_bit =1;

  tmod = 0x20;
  th1= -3;
  scon =0x50;
  tr1_bit=1;

  //all storage units are locked
  lock0=1;
  lock1=1;
  lock2=1;

 while(1)
 {
 
 }
}